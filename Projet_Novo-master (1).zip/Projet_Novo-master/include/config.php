<?php

$db_host = '127.0.0.1';
$db_port = '5432';
$db_user = 'root';
$db_pass = '1111';
$db_enc = 'UTF8';
$db_name = 'dict';

?>
