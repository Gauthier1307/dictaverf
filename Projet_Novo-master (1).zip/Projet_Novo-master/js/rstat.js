$(document).ready(function($) {
       $('.count-number').counterUp({
           delay: 10,
           time: 1000
       });
});
