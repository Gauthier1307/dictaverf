<script type="text/javascript" language="javascript">
    function do_onLoad(){}
</script>
<div class="experiment_content">
    <center>L'expérience se poursuit!<br>
	    Prenez part à l'expérience.
    </center>
<!--    <ul class="experiment_links">
        <li><a href="/mkdict/redir.php?t=4FRx9MlmlVNmA" class="dict1">Entrée</a> pour les habitants de la France métropolitaine</li>
        <li><a href="/mkdict/redir.php?t=16IiQtRLgAYrA" class="dict1">Entrée</a> pour les habitants des TOM DOM</li>
        <li><a href="/mkdict/redir.php?t=OW0LU1jT7Hl9c" class="dict1">Entrée</a> pour les habitants du Cameroun</li>
        <li><a href="/mkdict/redir.php?t=eMPamhq4rSWF2" class="dict1">Entrée</a> pour les habitants de Belgique</li>
        <li><a href="/mkdict/redir.php?t=9npQgdtDeftpY" class="dict1">Entrée</a> pour les habitants de Suisse</li>
        <li><a href="/mkdict/redir.php?t=1FhDnkdfHyHRA" class="dict1">Entrée</a> pour les habitants du Canada</li>
        <li><a href="/mkdict/redir.php?t=IUAKiKszUxqA." class="dict1">Entrée</a> pour les habitants du Liban</li>
        <li><a href="/mkdict/redir.php?t=F5gWV4DJyr7aw" class="dict1">Entrée</a> pour les habitants d’Egypte</li>
        <li><a href="/mkdict/redir.php?t=dfgtrbDFgd4r3" class="dict1">Entrée</a> pour les habitants du Congo Brazzaville</li>
        <li><a href="/mkdict/redir.php?t=1LF623Vmx8Noc" class="dict1">Entrée</a> pour tous les autres</li>
    </ul>
    <br>
    <br> -->
    <ul class="experiment_links">
        <!-- <li><a href="/mkdict/redir.php?t=dfDSrbDFgd4r3" class="dict1">Entrée</a>: NSU test</li>-->
        <li><a href="/mkdict_25/" class="dict1">Entrée</a>: NSU test</li>
    </ul>
</div>
<?php $url="http://dictaverf.nsu.ru/"; ?>
