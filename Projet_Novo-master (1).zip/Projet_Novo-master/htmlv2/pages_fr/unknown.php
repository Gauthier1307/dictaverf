<script type="text/javascript" language="javascript">
    function do_onLoad(){}
</script>
<?php $url="http://dictaverf.nsu.ru/"; ?>
