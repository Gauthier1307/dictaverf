<script type="text/javascript" language="javascript">
    function do_onLoad(){}
</script>


<?php
if($lang == "ru"){
?>

<div class="bg-primary pt-1" style="">
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-12"><img class="img-fluid d-block" src="http://dictaverf.nsu.ru/imgs/photos/nsu.jpg"></div>
    </div>
  </div>
</div>
<div class="py-3" style="">
  <div class="container">
    <div class="row">
      <div class="col-md-6 p-4">
        <h4><a href="about">Французский Ассоциативный Словарь (ФАС)</a></h4>
        <p>Материалом для этого словаря послужили ответы, полученные в ходе анкетирования
        2008-2010г., прошедшие только первичную  орфографическую обработку. Данный
        словарь дает богатый материал для изучения синтагматических связей между
        стимулом и реакцией</p>
      </div>
      <div class="col-md-6 p-4">
        <h4><a href="aboutj1">Словарь ассоциативных норм франкофонии (САНФ)</a></h4>
        <p style="">Материалом для этого словаря послужили ответы, полученные в ходе анкетирования
        2013-2015г ., прошедшие только первичную  орфографическую обработку. Данный
        словарь дает богатый материал для изучения синтагматических связей между
        стимулом и реакцией</p>
      </div>
      <div class="col-md-6 p-4">
        <h4><a href="aboutj">Словарь ассоциативных норм франкофонии (нормализованый)(САНФН)</a></h4>
        <p>Материалом для этого словаря послужили ответы, полученные в ходе анкетирования
        2013-2015., прошедшие унификацию: в одну статью собраны ответы, выраженные
        разными словоформами (мужской-женский род прилагательного, спрягаемые формы
        глагола), также убраны артикли и предлоги. Данный словарь не показывает
        синтагматическую сочетаемость стимула с реакцией, но дает более объективную
        картину их семантической сочетаемости. Это особенно важно для составления
        обратного словаря</p>
      </div>
      <div class="col-md-6 p-4">
        <h4><a href="about3">Словарь французских ассоциаций 2019 (ФАСН-2019)</a></h4>
        <p>Материалом для этого словаря послужили ответы, полученные в ходе анкетирования
        в 2018, прошедшие унификацию: в одну статью собраны ответы, выраженные
        разными словоформами (мужской-женский род прилагательного, спрягаемые формы
        глагола), также убраны артикли и предлоги. Данный словарь не показывает
        синтагматическую сочетаемость стимула с реакцией, но дает более объективную
        картину их семантической сочетаемости. Это особенно важно для составления
        обратного словаря. Особенность - в анкете давалось по 25 стимулов.</p>
      </div>
    </div>
  </div>
</div>

<?php
}else{
?>
<div class="bg-primary pt-1" style="">
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-12"><img class="img-fluid d-block" src="http://dictaverf.nsu.ru/imgs/photos/nsu.jpg"></div>
    </div>
  </div>
</div>
<div class="py-3" style="">
  <div class="container">
    <div class="row">
      <div class="col-md-6 p-4">
        <h4><a href="about">Dictionnaire associatif du français (DAF)</a></h4>
        <p>Ce dictionnaire est basé sur les réponses aux questionnaires remplis en 2008-2010. Seule l'orthographe et la ponctuation ont été rectifiées. Ce dictionnaire permet d'étudier les liens syntagmatiques entre le stimulus et la réaction.</p>
      </div>
      <div class="col-md-6 p-4">
        <h4><a href="aboutj1">Dictionnaire des normes associatives de la Francophonie (DINAF)</a></h4>
        <p style="">Ce dictionnaire est basé sur les réponses aux questionnaires remplis en 2013-2015. Seule l'orthographe et la ponctuation ont été rectifiées. Ce dictionnaire permet d'étudier les liens syntagmatiques entre le stimulus et la réaction.</p>
      </div>
      <div class="col-md-6 p-4">
        <h4><a href="aboutj">Dictionnaire des normes associatives de la Francophonie (normalisé) (DINAFN)</a></h4>
        <p>Ce dictionnaire est basé sur les réponses aux questionnaires remplis en 2013-2015. Outre la correction de l'orthographe et de la ponctuation, on a unifié les réponses: les réponses exprimées sous différentes formes (masculin - féminin de l'adjectif, formes verbales) sont réunies sous le même mot-vedette, les articles et les prépositions sont supprimées. Ce dictionnaire ne montre pas les liens syntagmatiques entre le stimulus et la réaction, mais il permet de mieux mettre ne évidence les liens sémantiques entre eux, cela est particulièrement important dans l'élaboration du dictionnaire inverse</p>
      </div>
      <div class="col-md-6 p-4">
        <h4><a href="about3">Dictionnaire des associations du français 2019 (DAF-2019)</a></h4>
        <p>Ce dictionnaire est basé sur les réponses aux questionnaires remplis en 2018. Outre la correction de l'orthographe et de la ponctuation, on a unifié les réponses: les réponses exprimées sous différentes formes (masculin - féminin de l'adjectif, formes verbales) sont réunies sous le même mot-vedette, les articles et les prépositions sont supprimées. Ce dictionnaire ne montre pas les liens syntagmatiques entre le stimulus et la réaction, mais il permet de mieux mettre ne évidence les liens sémantiques entre eux, cela est particulièrement important dans l'élaboration du dictionnaire inverse. </p>
      </div>
    </div>
  </div>
</div>
<?php
}
?>

<!-- JavaScript dependencies -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<!-- Script: Smooth scrolling between anchors in the same page -->
<script src="js/smooth-scroll.js"></script>

<!-- JavaScript dependencies -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<!-- Script: Smooth scrolling between anchors in the same page -->
<script src="js/smooth-scroll.js"></script>

<?php $url="http://dictaverf.nsu.ru/authors"; ?>
