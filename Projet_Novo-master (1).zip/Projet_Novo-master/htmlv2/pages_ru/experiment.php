<script type="text/javascript" language="javascript">
    function do_onLoad(){}
</script>
<div class="experiment_content">
    <center>Эксперимент продолжается!<br>
    Прими участие в эксперименте.
    </center>
<!--   <ul class="experiment_links">
        <li><a href="/mkdict/redir.php?t=4FRx9MlmlVNmA" class="dict1">Вход</a> для жителей "Континентальной Франции"</li>
        <li><a href="/mkdict/redir.php?t=16IiQtRLgAYrA" class="dict1">Вход</a> для жителей заморских французских территорий</li>
        <li><a href="/mkdict/redir.php?t=OW0LU1jT7Hl9c" class="dict1">Вход</a> для жителей Камеруна</li>
        <li><a href="/mkdict/redir.php?t=eMPamhq4rSWF2" class="dict1">Вход</a> для жителей Бельгии</li>
        <li><a href="/mkdict/redir.php?t=9npQgdtDeftpY" class="dict1">Вход</a> для жителей Швейцарии</li>
        <li><a href="/mkdict/redir.php?t=1FhDnkdfHyHRA" class="dict1">Вход</a> для жителей Канады</li>
        <li><a href="/mkdict/redir.php?t=IUAKiKszUxqA." class="dict1">Вход</a> для жителей Ливана</li>
        <li><a href="/mkdict/redir.php?t=F5gWV4DJyr7aw" class="dict1">Вход</a> для жителей Египта</li>
        <li><a href="/mkdict/redir.php?t=dfgtrbDFgd4r3" class="dict1">Вход</a> для жителей Конго</li>
        <li><a href="/mkdict/redir.php?t=1LF623Vmx8Noc" class="dict1">Вход</a> для всех остальных</li>
    </ul>
    <br>
    <br> -->
    <ul class="experiment_links">
        <li><a href="/mkdict/redir.php?t=dfDSrbDFgd4r3" class="dict1">Вход</a>: NSU test</li>
    </ul>
</div>
