<script type="text/javascript" language="javascript">
    function do_onLoad(){}
</script>
<div class="authors_content">
  <table width="100%" border=0>
    <tr>
      <td width="40%" style="text-align:center;">
        <img class="ui circular image" src="imgs/photos/Debrenn.png" border="1"  alt="photo"/>
      </td>
      <td valign="middle">
        <span class="FIO">Дебренн Мишель</span><br>
  			<span class="who">Руковолитель</span><br>
  			<span class="degree">д.ф.н., профессор кафедры французского языка факультета иностранных языков НГУ</span><br>
        <img src="<?php echo $basedir; ?>imgs/ico/mail.png" alt="email"/><span class="email"><a href="mailto:micheledebrenne@gmail.com">micheledebrenne@gmail.com</a></span><br>
      </td>
    </tr>
    <tr>
      <td width="40%">
        <img class="ui circular image" src="imgs/photos/ufimtseva.png" border="1" alt="photo"/>
      </td>
      <td valign="middle">
        <span class="FIO">Уфимцева Наталья Владимировна</span><br>
        <span class="who">&nbsp;</span><br>
        <span class="degree">д.ф.н., профессор Института Языкознания РАН</span><br>
        <img src="<?php echo $basedir; ?>imgs/ico/mail.png" alt="email" style="display:none;"/><span class="email"><a class="mailto" href="#">&nbsp;</a><span><br>
      </td>
    </tr>
    <tr>
      <td width="40%">
        <img class="ui circular image" src="imgs/photos/Romanenko.png" border="1" alt="photo"/>
      </td>
      <td valign="middle">
        <span class="FIO">Романенко Алексей Анатольевич</span><br>
        <span class="who">Автор системы. Техническое сопровождение</span><br>
        <span class="degree">к.т.н., зав. отделом компьютерной техники ФИТ НГУ</span><br>
        <img src="<?php echo $basedir; ?>imgs/ico/mail.png" alt="email"/><span class="email"><a href="mailto:arom@ccfit.nsu.ru">arom@ccfit.nsu.ru</a></span><br>
      </td>
    </tr>
  </table>
</div>
<?php $url="http://dictaverf.nsu.ru/authors1"; ?>
