<?php

$db_host = 'localhost';
$db_port = '5432';
$db_user = 'dict';
$db_pass = 'eisti';
$db_enc = 'UTF8';
$db_name = 'dict';

?>
