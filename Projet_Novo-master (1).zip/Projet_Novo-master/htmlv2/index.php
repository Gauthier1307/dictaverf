<?php include("include/init.php");?>
<?php include("include/header.php"); ?>
<!-- <div class="top_line">
	<a href="/" style="float:left;"> <img class="logo" border=0 src="<?php echo $basedir; ?>imgs/ico/home.png" alt="home"/></a>
	<a href="ru" style="float:right;"><img class="logo" border=0 src="<?php echo $basedir; ?>imgs/ico/russia.png" alt="ru"/></a>
	<a href="fr" style="float:right;"><img class="logo" border=0 src="<?php echo $basedir; ?>imgs/ico/france.png" alt="fr"/></a>
</div> -->

<!-- Dict menu -->
<!--
<?php if ($page!="intro") { ?>
<div class="menu_dict">
	<div class="ui menu">
	  <div class="ui simple dropdown item">
	    <?php echo $locale["dict"]; ?>
	    <i class="dropdown icon"></i>
	    <div class="menu">
	      <a class="item" href="/about"><?php echo $locale["DAF"]; ?></a>
	      <a class="item" href="/aboutj1"><?php echo $locale["DINAF"]; ?></a>
	      <a class="item" href="/aboutj"><?php echo $locale["DINAFN"]; ?></a>
	      <a class="item" href="/about3"><?php echo $locale["DINAFN1"]; ?></a>
	    </div>
	  </div>
	</div>
</div>
<?php } ?>
-->
<!--<div class="menu_bg">-->
	<div id="navigator">
<!--	<ul id="nav-menu"> -->


<!-- .........................................	DAF  .......................................... -->

<?php
    	if(($page=="dict") ||($page=="experiment")||($page=="about")||($page=="authors") || ($page =="help")) {
?>

<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
	<div class="container"> <a class="navbar-brand" href="/"><i class="fa fa-fw fa-home">&nbsp;Accueil</i></a> <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
		<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
			<ul class="navbar-nav">
				<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="about" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Changer de Dictionnaire&nbsp;</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="/about">DAF</a> <a class="dropdown-item" href="aboutj1">DINAF</a> <a class="dropdown-item" href="aboutj">DINAFN</a> <a class="dropdown-item" href="about3">DAF-2019<br></a></div>
				</li>
			</ul>
			<ul class="navbar-nav">
				<li class="nav-item mx-2"> <a class="nav-link" href="about">Le Projet</a> </li>
				<li class="nav-item mx-2"> <a class="nav-link" href="authors">Auteurs</a> </li>
				<li class="nav-item"><a class="nav-link" href="dict">Dictionnaire</a></li>
				<li class="nav-item"><a class="nav-link" href="help">Aide</a></li>
			</ul> <a class="btn navbar-btn text-white mx-2 btn-primary" href="ru">Russian<br></a>
		</div>
	</div>
</nav>

<!-- old
		<li <?php if($page=="about"){echo "id=\"nav-menu-act\"";}?>><a href="about"><?php echo $locale['about']; ?></a></li>
		<li <?php if($page=="authors"){echo "id=\"nav-menu-act\"";}?>><a href="authors"><?php echo $locale['authors']; ?></a></li>
		<li <?php if($page=="dict"){echo "id=\"nav-menu-act\"";}?>><a href="dict"><?php echo $locale['dict']; ?></a></li>
		<li <?php if($page=="help"){echo "id=\"nav-menu-act\"";}?>><a href="help"><?php echo $locale['help']; ?></a></li>
-->


<!-- .........................................	DINAF  .......................................... -->

<?php } elseif(($page=="joint1")||($page=="bjoint1")||($page=="aboutj1")||($page=="authorsj1") || ($page=="helpj1")) { ?>


	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		<div class="container"> <a class="navbar-brand" href="/"><i class="fa fa-fw fa-home">&nbsp;Accueil</i></a> <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
			<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
				<ul class="navbar-nav">
					<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="about" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Changer de Dictionnaire&nbsp;</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="/about">DAF</a> <a class="dropdown-item" href="aboutj1">DINAF</a> <a class="dropdown-item" href="aboutj">DINAFN</a> <a class="dropdown-item" href="about3">DAF-2019<br></a></div>
					</li>
				</ul>
				<ul class="navbar-nav">
					<li class="nav-item mx-2"> <a class="nav-link" href="aboutj1">Le Projet</a> </li>
					<li class="nav-item mx-2"> <a class="nav-link" href="authorsj1">Auteurs</a> </li>
					<li class="nav-item"><a class="nav-link" href="joint1">Dictionnaire</a></li>
					<li class="nav-item"><a class="nav-link" href="helpj1">Aide</a></li>
				</ul> <a class="btn navbar-btn text-white mx-2 btn-primary" href="ru">Russian<br></a>
			</div>
		</div>
	</nav>


<!-- old
		<li <?php if($page=="aboutj1"){echo "id=\"nav-menu-act\"";}?>><a href="aboutj1"><?php echo $locale['about']; ?></a></li>
		<li <?php if($page=="authorsj1"){echo "id=\"nav-menu-act\"";}?>><a href="authorsj1"><?php echo $locale['authors']; ?></a></li>
		<li <?php if($page=="joint1"){echo "id=\"nav-menu-act\"";}?>><a href="joint1"><?php echo $locale['dict']; ?></a></li>
		<li <?php if($page=="helpj1"){echo "id=\"nav-menu-act\"";}?>><a href="helpj1"><?php echo $locale['help']; ?></a></li>
-->

<!-- .........................................	DINAFN  .......................................... -->

<!--		<li <?php if($page=="experiment"){echo "id=\"nav-menu-act\"";}?>><a href="experiment"><?php echo $locale['experiments']; ?></a></li> -->
<?php } elseif(($page=="joint")||($page=="bjoint")||($page=="aboutj")||($page=="authorsj") || ($page=="helpj")) { ?>

	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		<div class="container"> <a class="navbar-brand" href="/"><i class="fa fa-fw fa-home">&nbsp;Accueil</i></a> <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
			<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
				<ul class="navbar-nav">
					<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="about" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Changer de Dictionnaire&nbsp;</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="/about">DAF</a> <a class="dropdown-item" href="aboutj1">DINAF</a> <a class="dropdown-item" href="aboutj">DINAFN</a> <a class="dropdown-item" href="about3">DAF-2019<br></a></div>
					</li>
				</ul>
				<ul class="navbar-nav">
					<li class="nav-item mx-2"> <a class="nav-link" href="aboutj">Le Projet</a> </li>
					<li class="nav-item mx-2"> <a class="nav-link" href="authorsj">Auteurs</a> </li>
					<li class="nav-item"><a class="nav-link" href="joint">Dictionnaire</a></li>
					<li class="nav-item"><a class="nav-link" href="helpj">Aide</a></li>
				</ul> <a class="btn navbar-btn text-white mx-2 btn-primary" href="ru">Russian<br></a>
			</div>
		</div>
	</nav>


<!-- old
		<li <?php if($page=="aboutj"){echo "id=\"nav-menu-act\"";}?>><a href="aboutj"><?php echo $locale['about']; ?></a></li>
		<li <?php if($page=="authorsj"){echo "id=\"nav-menu-act\"";}?>><a href="authorsj"><?php echo $locale['authors']; ?></a></li>
		<li <?php if($page=="joint"){echo "id=\"nav-menu-act\"";}?>><a href="joint"><?php echo $locale['dict']; ?></a></li>
		<li <?php if($page=="helpj"){echo "id=\"nav-menu-act\"";}?>><a href="helpj"><?php echo $locale['help']; ?></a></li>
-->


<!-- .........................................	DAF2019 .......................................... -->

<?php } elseif(($page=="dict3")||($page=="about3")||($page=="authors3") || ($page=="help3")) { ?>

	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		<div class="container"> <a class="navbar-brand" href="/"><i class="fa fa-fw fa-home">&nbsp;Accueil</i></a> <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
			<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
				<ul class="navbar-nav">
					<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="about" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Changer de Dictionnaire&nbsp;</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="/about">DAF</a> <a class="dropdown-item" href="aboutj1">DINAF</a> <a class="dropdown-item" href="aboutj">DINAFN</a> <a class="dropdown-item" href="about3">DAF-2019<br></a></div>
					</li>
				</ul>
				<ul class="navbar-nav">
					<li class="nav-item mx-2"> <a class="nav-link" href="about3">Le Projet</a> </li>
					<li class="nav-item mx-2"> <a class="nav-link" href="authors3">Auteurs</a> </li>
					<li class="nav-item"><a class="nav-link" href="dict3">Dictionnaire</a></li>
					<li class="nav-item"><a class="nav-link" href="help3">Aide</a></li>
				</ul> <a class="btn navbar-btn text-white mx-2 btn-primary" href="ru">Russian<br></a>
			</div>
		</div>
	</nav>


<!-- old
		<li <?php if($page=="about3"){echo "id=\"nav-menu-act\"";}?>><a href="about3"><?php echo $locale['about']; ?></a></li>
		<li <?php if($page=="authors3"){echo "id=\"nav-menu-act\"";}?>><a href="authors3"><?php echo $locale['authors']; ?></a></li>
		<li <?php if($page=="dict3"){echo "id=\"nav-menu-act\"";}?>><a href="dict3"><?php echo $locale['dict']; ?></a></li>
		<li <?php if($page=="help3"){echo "id=\"nav-menu-act\"";}?>><a href="help3"><?php echo $locale['help']; ?></a></li>
-->





<?php } else { ?>

	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		<div class="container"> <a class="navbar-brand" href="/"><i class="fa fa-fw fa-home">&nbsp;Accueil</i></a> <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
			<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
				<ul class="navbar-nav">
					<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="intro" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Changer de Dictionnaire&nbsp;</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="/about">DAF</a> <a class="dropdown-item" href="aboutj1">DINAF</a> <a class="dropdown-item" href="aboutj">DINAFN</a> <a class="dropdown-item" href="about3">DAF-2019<br></a></div>
					</li>
				</ul>
				<ul class="navbar-nav">
					<li class="nav-item mx-2"> <a class="nav-link" href="authors">Auteurs</a> </li>
				</ul> <a class="btn navbar-btn text-white mx-2 btn-primary" href="ru">Russian<br></a>
			</div>
		</div>
	</nav>

<?php } ?>
	</ul>
	</div>
</div>
<!-- <div class="content"> -->
<?php
if($lang == "ru"){
?>
<div class="bg-primary pt-1" style="">
  <div class="container mt-5 pt-5">
    <div class="row">
      <div class="col-md-6 my-5 text-lg-left text-center align-self-center">
        <div class="row">
          <div class="col-md-12" style="">
            <h1 class="">Ассоциативные словари французского языка</h1>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <h6 class=""><br><br><br></h6>
              </div>
            </div><a href="https://www.nsu.ru/n/"><img class="img-fluid d-block" src="https://newarchaeology.nsu.ru/images/tild3930-6364-4163-a439-333364653732__noroot.png" style=""></a>
            <div class="row">
              <div class="col-md-12">
                <h6 class="" contenteditable="false"><br><br></h6>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
}else{
?>
<div class="bg-primary pt-1" style="">
  <div class="container mt-5 pt-5">
    <div class="row">
      <div class="col-md-6 my-5 text-lg-left text-center align-self-center">
        <div class="row">
          <div class="col-md-12" style="">
            <h1 class="">Dictionnaires des associations verbales du Français</h1>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <h6 class=""><br><br><br></h6>
              </div>
            </div><a href="https://english.nsu.ru/"><img class="img-fluid d-block" src="https://newarchaeology.nsu.ru/images/tild3930-6364-4163-a439-333364653732__noroot.png" style=""></a>
            <div class="row">
              <div class="col-md-12">
                <h6 class="" contenteditable="false"><br><br></h6>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
}
?>
<?php
	if(       ($page=="about")
		||($page=="about3")
		||($page=="aboutj")
		||($page=="aboutj1")
		||($page=="help")
		||($page=="help3")
		||($page=="helpj")
		||($page=="helpj1")
		||($page=="authors")
		||($page=="authors3")
		||($page=="authorsj")
		||($page=="authorsj1")
		||($page=="dict")
		||($page=="dict3")
		||($page=="intro")
		||($page=="joint")
		||($page=="joint1")
		||($page=="bjoint")
		||($page=="bjoint1")
		||($page=="experiment")){
			include("pages_".$lang."/".$page.".php");
		}
	  else
	  {
	  		include("pages_".$lang."/unknown.php");
	  }
		?>
<!-- </div> -->

<?php include("include/footer.php"); ?>
